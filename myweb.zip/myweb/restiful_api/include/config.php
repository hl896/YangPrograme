<?php
/**
 * Created by PhpStorm.
 * User: yang
 * Date: 03/08/2017
 * Time: 2:00 PM
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "yang_system");

?>

